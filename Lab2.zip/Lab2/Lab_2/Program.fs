﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "Hello from Bbek"


type Coach = { Name: string; FormerPlayer: bool }
type Stats = { Wins: int; Losses: int }
type Team = { Name: string; Coach: Coach; Stats: Stats }

let coaches = [
    { Name = "Quin Snyder"; FormerPlayer = true }
    { Name = "Joe Mazzulla"; FormerPlayer = true }
    { Name = "Kevin Ollie"; FormerPlayer = false }
    { Name = "Steve Clifford"; FormerPlayer = true }
    { Name = "Billy Donovan"; FormerPlayer = false }
]

let teams = [
    { Name = "Atlanta Hawks"; Coach = coaches.[0]; Stats = { Wins = 35; Losses = 40 } }
    { Name = "Boston Celtics"; Coach = coaches.[1]; Stats = { Wins = 59; Losses = 16 } }
    { Name = "Brooklyn Nets"; Coach = coaches.[2]; Stats = { Wins = 9; Losses = 14 } }
    { Name = "Charlotte Hornets"; Coach = coaches.[3]; Stats = { Wins = 18; Losses = 57 } }
    { Name = "Chicago Bulls"; Coach = coaches.[4]; Stats = { Wins = 36; Losses = 40 } }
]


let successfulTeams = teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)
let successPercentages = teams |> List.map (fun team -> float team.Stats.Wins / float(team.Stats.Wins + team.Stats.Losses) * 100.0)


printfn "Successful Teams:"
successfulTeams |> List.iter (fun team -> printfn "%s - Wins: %d, Losses: %d" team.Name team.Stats.Wins team.Stats.Losses)


printfn "\nSuccess Percentages:"
List.iter2 (fun team percentage -> printfn "%s: %.2f%%" team.Name percentage) teams successPercentages







type Cuisine = Korean | Turkish
type MovieType = Regular | IMAX | DBOX | RegularWithSnacks | IMAXWithSnacks | DBOXWithSnacks
type Recreation = BoardGame | Chill | Movie of MovieType | Restaurant of Cuisine | LongDrive of int * float

let calculateBudget recreation =
    match recreation with
    | BoardGame | Chill -> 0.0
    | Movie Regular -> 12.0
    | Movie IMAX -> 17.0
    | Movie DBOX -> 20.0
    | Movie _ -> 20.0 + 5.0
    | Restaurant Korean -> 70.0
    | Restaurant Turkish -> 65.0
    | LongDrive (km, fuel) -> float km * fuel

let recreation1 = Restaurant Turkish
let recreation2 = Movie DBOXWithSnacks
let recreation3 = LongDrive (120, 0.2)


let budget1 = calculateBudget recreation1
let budget2 = calculateBudget recreation2
let budget3 = calculateBudget recreation3

let totalBudget = budget1 + budget2 + budget3

printfn "Budget for Cuisine: %.2f CAD" budget1
printfn "Budget for Movies: %.2f CAD" budget2
printfn "Budget for LongDrive: %.2f CAD" budget3
printfn "Total Budget: %.2f CAD" totalBudget






